# InSAR Suite

**Plugin QGIS per l'analisi dei dati PSI / QGIS plugin for PSI data analysis**

---

## 🇮🇹 Italiano

### Descrizione

InSAR Suite è un plugin QGIS che raccoglie in un'unica toolbar dedicata gli strumenti per l'analisi dei dati PSI (Persistent Scatterer Interferometry). Il plugin nasce per semplificare il flusso di lavoro nell'analisi di dataset nazionali (es. EGMS Italia) e locali, coprendo tutte le fasi dall'acquisizione dati alla visualizzazione avanzata delle serie storiche.

La versione 3.0 ridisegna completamente il modulo TS: la verifica di normalità è sostituita da un modulo di qualità del dato più completo, vengono aggiunti tre nuovi strumenti (rilevamento anomalie temporali, confronto tra zone, selettore di trasformazione in tempo reale) e la geostatistica è spostata su script standalone.

La versione 3.1 introduce il fix del crash matplotlib alla chiusura di QGIS, aggiunge controlli di validità del layer attivo nei moduli TS, il controllo del CRS nel modulo VIS, aggiorna i preset satellitari e aggiunge RADARSAT-2.

La versione 3.2 aggiunge skewness e kurtosis all'analisi qualità TS, supporta il formato data YYYYMMDD (oltre a DYYYYMMDD), introduce il pulsante "Carica PS coerenti in QGIS" nei grafici TS, aggiunge celle esagonali nel modulo EWUD, consente il salvataggio permanente dell'output VIS, aggiorna i preset satellitari con azimut ASC in convenzione positiva ([0°, 360°]) e introduce il nuovo modulo **InSAR Polygons** per la delimitazione automatica delle aree di deformazione.

La versione 3.2.1 corregge un bug nel modulo EWUD che su alcuni sistemi causava lo scambio dei campi Va/Na/Vd/Nd, e aggiunge la compatibilità con schermi di dimensioni ridotte nel modulo InSAR Polygons.

La versione 3.2.2 corregge due bug indipendenti da QGIS 4 (emersi durante i test della versione parallela per QGIS 4, ma presenti anche qui): l'abbinamento dei PS coerenti nel modulo TS falliva quando il layer sorgente non ha un campo chiamato esattamente "CODE" (ora ricade coerentemente sull'ID interno della feature, come già faceva la fase di analisi); e i layer salvati dal modulo EWUD (griglia, Centroidi_EWUD, Poligoni_EWUD) avevano un nome fisso indipendentemente dal file scelto, rendendo indistinguibili run diversi salvati con nomi diversi.

La versione 3.2.3 corregge il salvataggio permanente della griglia EWUD: GDAL interpretava il campo "id" come candidato per la chiave primaria del GeoPackage, il che poteva alterare la corrispondenza tra le celle della griglia e i valori calcolati dopo il ricaricamento (con conseguenti campi Va/Vd/Na/Nd nulli in Centroidi_EWUD/Poligoni_EWUD). Il campo è stato rinominato in "grid_id" per evitare l'ambiguità; il calcolo avviene ora sempre in memoria, con il salvataggio su file come passaggio separato.

La versione 3.2.5 introduce il nuovo modulo **InSAR Report**: genera automaticamente un report riepilogativo dell'analisi PSInSAR su un'area di studio (disegnata a mano, caricata da file o selezionata da un layer già nel progetto), con numero di PS, densità (PS/kmq), copertura areale, coerenza cinematica, visibilità e velocità media ± deviazione standard per i dataset ascendente e discendente, oltre al vettore EWUD medio (con statistica circolare per l'angolo). I layer VIS ed EWUD selezionati non necessitano di essere ritagliati sull'area di studio. Esportabile come PNG o CSV.

La versione 3.2.6 aggiunge il rilevamento dell'accelerazione al modulo InSAR Report: per ciascun dataset (ascendente/discendente), una regressione piecewise a **esattamente 2 segmenti fissi** (1 solo breakpoint, la cui posizione ottimale viene comunque cercata automaticamente) viene adattata alla serie storica media dei PS coerenti, dopo aver rimosso la componente stagionale (termica/idrologica, tipica dei dati PSI; periodo stimato dalla cadenza reale di acquisizione). Viene riportato il rapporto tra le velocità dei due segmenti (soglia configurabile, default 1.5) insieme alla data del breakpoint; un'eventuale inversione di direzione tra i due segmenti viene segnalata separatamente. Il numero di segmenti è deliberatamente fissato a 2, non scelto tramite BIC: un rapporto di velocità significativo richiede sempre e solo due velocità da confrontare, e i modelli piecewise "a nodi liberi" tendono a far preferire al BIC più segmenti di quanto sia realmente giustificato (vedi la nota sul modulo TS qui sotto). Aggiunto anche il numero di celle EWUD che ricadono nell'area di studio, accanto al vettore EWUD medio. Corregge inoltre un bug (nome errato di un attributo della libreria pwlf, ".rss" invece di ".ssr") nello strumento TS "Analisi non lineare piecewise", che faceva fallire silenziosamente la selezione automatica del numero di segmenti tramite BIC (ricadeva sempre sullo stesso valore predefinito invece di testare realmente il BIC); corretta anche la non riproducibilità dei risultati dell'ottimizzatore pwlf fissando un seed, e rimossa la componente stagionale prima del fit per lo stesso motivo di cui sopra. Il valore di default di "Numero massimo di segmenti" è ora 2 (era 5), sempre modificabile dall'utente; da notare che, a differenza del modulo Report, questo strumento continua a scegliere tramite BIC tra 2 e 5 segmenti e può occasionalmente preferire più segmenti di quanti un geologo si aspetterebbe, per l'effetto BIC "a nodi liberi" appena descritto — è un limite noto del metodo, non un bug, e per ora resta affidato al giudizio dell'utente.

La versione 3.3.0 introduce la compatibilità con **QGIS 4 / Qt6**, distribuita come ramo separato (vedi sezione Installazione). Il porting ha richiesto la correzione di numerosi riferimenti a enum Qt e QGIS non più validi in Qt6 (allineamento testo, dialoghi, messaggi, tipi di campo), l'adeguamento del meccanismo di caricamento degli script standalone del modulo TS, la correzione di un conflitto GDAL sul campo fid nei GeoPackage e di un bug di abbinamento dei PS coerenti (entrambi indipendenti da QGIS 4, ma emersi durante i test). Aggiunge inoltre il salvataggio permanente su GeoPackage al modulo **InSAR Polygons** (come già presente in VIS ed EWUD). La linea 3.2.x per QGIS 3 continua a essere mantenuta in parallelo.

La versione 3.3.1 corregge lo stesso bug di salvataggio della griglia EWUD risolto nella 3.2.3 per QGIS 3 (vedi sopra), indipendente da QGIS 4 ma emerso durante i test su questo ramo.

La versione 3.3.3 porta su questo ramo lo stesso modulo **InSAR Report** introdotto nella 3.2.6 per QGIS 3 (vedi sopra), incluso il rilevamento dell'accelerazione, con funzionalità identiche.

### Moduli

| Modulo | Descrizione |
|--------|-------------|
| **InSAR Load** | Caricamento layer PS da GeoPackage, Shapefile o GDB tramite un quadro di unione poligonale, con attivazione automatica al clic su mappa. Supporta anche il ricaricamento di un quadro già presente nel progetto. |
| **InSAR EWUD** | Ricostruzione del vettore velocità nel piano Est-Ovest / Up-Down dalle velocità LOS di coppie ascending/descending. Griglia di ricampionamento con celle quadrate o esagonali. Preset satellitari inclusi (Sentinel-1 EGMS - Italia centro-settentrionale, Sentinel-1 generico, ERS/Envisat, ALOS/ALOS-2, RADARSAT-2, COSMO-SkyMed, TerraSAR-X/TanDEM-X). Output con campi Na e Nd (numero PS per cella). |
| **InSAR VIS** | Calcolo della percentuale di movimento rilevabile (pc_mov) in funzione della geometria SAR e della morfologia del terreno (Aspect/Slope da DEM). Il DEM viene ritagliato alla risoluzione originale con snap to grid (targetAlignedPixels). Output salvabile come GeoPackage permanente. Preset satellitari inclusi (stessi di EWUD). Elaborazione tramite QgsTask (GUI non bloccante). |
| **InSAR TS** | Analisi serie storiche: qualità del dato (con skewness e kurtosis), analisi cinematica automatica, scomposizione STL, analisi non lineare piecewise (pwlf), rilevamento anomalie temporali, confronto tra zone. Supporto formati data DYYYYMMDD e YYYYMMDD. Pulsante "Carica PS coerenti in QGIS" disponibile nei grafici. |
| **InSAR Polygons** | Delimitazione automatica delle aree di deformazione: classificazione PS per soglia di velocità, buffer e dissolve geometrico per classe, validazione e smoothing morfologico. Output poligonale con attributi statistici (velocità media, n. PS, area km²). Output salvabile come GeoPackage permanente (dalla v3.3.0). |
| **InSAR Report** | Genera automaticamente un report riepilogativo dell'analisi PSInSAR su un'area di studio (disegnata, caricata da file o selezionata da un layer del progetto): numero di PS, densità, copertura areale, coerenza cinematica, visibilità e velocità (con deviazione standard) per i dataset ascendente e discendente, rilevamento dell'accelerazione (soglia configurabile) e vettore EWUD medio con numero di celle nell'area. Esportabile in PNG o CSV. |

### Preset satellitari (moduli VIS e EWUD)

| Satellite | Banda | ASC az | ASC on | DESC az | DESC on |
|-----------|-------|--------|--------|---------|---------|
| Sentinel-1 (EGMS - Italia centro-settentrionale) | C | 349° | 42° | 191° | 38° |
| Sentinel-1 (generico) | C | 348° | 33° | 192° | 33° |
| ERS / Envisat | C | 347° | 23° | 193° | 23° |
| ALOS / ALOS-2 | L | 350° | 34° | 190° | 34° |
| RADARSAT-2 | C | 350° | 35° | 190° | 35° |
| COSMO-SkyMed | X | 345° | 30° | 195° | 30° |
| TerraSAR-X / TanDEM-X | X | 350° | 35° | 190° | 35° |

> Gli azimut ASC sono espressi nella convenzione [0°, 360°] (es. 349° = −11°). Il risultato delle formule è identico — sin(349°) = sin(−11°).

### Strumenti del modulo TS

| Strumento | Descrizione |
|-----------|-------------|
| **Qualità del dato** | Istogramma + curva normale N(μ,σ), Q-Q plot, boxplot con dati individuali, statistiche robuste (media, std, mediana, IQR, MAD, skewness, kurtosis, z-score robusto, Shapiro-Wilk). Selettore trasformazione in tempo reale. Pulsante "Carica PS coerenti in QGIS". |
| **Analisi automatica** | Serie storica media ±1σ, trend OLS con velocità e R², tooltip interattivo, pulsante per caricare la tabella in QGIS. Pulsante "Carica PS coerenti in QGIS". |
| **Scomposizione STL** | Scomposizione della serie media in trend T(t), stagionalità S(t) e residuo R(t). Pulsante "Carica PS coerenti in QGIS". |
| **Analisi non lineare** | Regressione piecewise (pwlf), ottimizzazione BIC, numero massimo di segmenti configurabile (2–5), tabella riepilogativa con periodo, velocità e R² per ogni segmento. Pulsante "Carica PS coerenti in QGIS". |
| **Anomalie temporali** | Rilevamento acquisizioni anomale su residui (soglia nσ) e variazioni consecutive (soglia Δmm). Tooltip ⚠ ANOMALIA sulle date anomale. |
| **Confronto tra zone** | Confronto serie medie tra 2–3 zone con pannello non modale, bande ±1σ e rette OLS. |

### Requisiti

- **QGIS 3.16 – 3.99** (plugin v3.2.x) oppure **QGIS 4.00+** (plugin v3.3.x, Qt6)
- Python 3 con librerie: `pandas`, `numpy`, `matplotlib`, `scipy`, `statsmodels`, `pyproj`, `mplcursors`, `pwlf`

> A partire dalla v3.0 la libreria `pykrige` non è più richiesta dalla toolbar principale. La geostatistica è disponibile come script standalone nella cartella `docs/`.

### Installazione

**Dal QGIS Plugin Repository (consigliato):**
1. In QGIS: *Plugin → Gestisci e installa plugin → Tutti*
2. Cerca **InSAR Suite** e clicca su *Installa plugin*

Le nuove versioni vengono pubblicate nel repository ufficiale dopo revisione da parte di un moderatore (generalmente entro un giorno lavorativo, esclusi i weekend; a volte possono volerci alcuni giorni in più).

**Da ZIP:**
1. Scarica lo ZIP corrispondente alla tua versione di QGIS dalla pagina [Releases](../../releases): `InSAR_Suite_v3.2.6_QGIS3.zip` per QGIS 3, `InSAR_Suite_v3.3.3_QGIS4.zip` per QGIS 4
2. In QGIS: *Plugin → Gestisci e installa plugin → Installa da ZIP*
3. Abilita il plugin dall'elenco degli installati

**Installazione manuale:**

Copiare la cartella `InSAR_Suite/` nella directory dei plugin di QGIS:
- Windows (QGIS 3): `C:\Users\<utente>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Windows (QGIS 4): `C:\Users\<utente>\AppData\Roaming\QGIS\QGIS4\profiles\default\python\plugins\`
- Linux / macOS (QGIS 3): `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- Linux / macOS (QGIS 4): `~/.local/share/QGIS/QGIS4/profiles/default/python/plugins/`

### Utilizzo rapido

1. **Load** — Carica il layer PS puntuale selezionando i poligoni del quadro di unione
2. **EWUD** — Crea la griglia (quadrata o esagonale) e ricostruisci il vettore velocità EW-UD da ascending/descending
3. **VIS** — Seleziona il layer PS e il DEM, definisci l'estensione di elaborazione e calcola pc_mov
4. **TS** — Imposta il layer PS come attivo, seleziona i punti sulla mappa, avvia le analisi nell'ordine: Qualità del dato → Analisi automatica → Scomposizione STL → Non lineare → Anomalie → Confronto zone
5. **Polygons** — Seleziona il layer PS, configura soglia di velocità e raggio buffer, avvia la delimitazione automatica delle aree di deformazione

> I moduli TS richiedono che il layer PS vettoriale sia attivo e che siano presenti punti selezionati. Se il layer attivo è un raster o non è presente alcuna selezione, il plugin mostra una finestra di avviso con le istruzioni per procedere.

### Formato dati atteso per il modulo TS

I layer PS devono contenere campi di spostamento nel formato `DYYYYMMDD` (es. `D20170101`) oppure `YYYYMMDD` (es. `20170101`), un campo per ogni data di acquisizione SAR. Il plugin riconosce automaticamente entrambi i formati.

### Segnalazione bug e contributi

Apri una [Issue](../../issues) su GitHub per segnalare problemi o proporre miglioramenti.

---

## 🇬🇧 English

### Description

InSAR Suite is a QGIS plugin that consolidates PSI (Persistent Scatterer Interferometry) analysis tools into a single dedicated toolbar. It is designed to streamline the analysis workflow for national (e.g. EGMS Italy) and local PSI datasets, covering all stages from data loading to advanced time series analysis.

Version 3.0 completely redesigns the TS module: the normality check is replaced by a more comprehensive data quality analysis, three new tools are added (temporal anomaly detection, multi-zone comparison, real-time transformation selector), and geostatistics is moved to a standalone script.

Version 3.1 introduces a fix for the matplotlib crash on QGIS exit, adds layer validity checks in TS modules, a CRS check in the VIS module, and updates satellite presets.

Version 3.2 adds skewness and kurtosis to the TS quality analysis, supports the YYYYMMDD date format (in addition to DYYYYMMDD), introduces a "Load coherent PS to QGIS" button in TS charts, adds hexagonal cell support in EWUD, allows permanent saving of VIS output, updates satellite presets to positive ASC azimuth convention ([0°, 360°]), and introduces the new **InSAR Polygons** module for automatic delineation of deformation areas.

Version 3.2.1 fixes a bug in the EWUD module that on some systems caused the Va/Na/Vd/Nd fields to be swapped, and adds scrollable window support for small screens in the InSAR Polygons module.

Version 3.2.2 fixes two bugs unrelated to QGIS 4 (surfaced while testing the parallel QGIS 4 version, but also present here): coherent-PS matching in the TS module failed when the source layer has no field literally named "CODE" (now falls back consistently to the internal feature ID, as already done during the analysis phase); and layers saved from the EWUD module (grid, Centroidi_EWUD, Poligoni_EWUD) had a fixed name regardless of the chosen file, making different runs saved under different names indistinguishable.

Version 3.2.3 fixes permanent saving of the EWUD grid: GDAL was interpreting the "id" field as a candidate for the GeoPackage primary key, which could alter the correspondence between grid cells and computed values after reload (resulting in null Va/Vd/Na/Nd fields in Centroidi_EWUD/Poligoni_EWUD). The field was renamed to "grid_id" to avoid the ambiguity; computation now always happens in memory, with file saving as a separate step.

Version 3.2.5 introduces the new **InSAR Report** module: automatically generates a PSInSAR summary sheet for a study area (hand-drawn, loaded from a file, or picked from a layer already in the project), with PS count, density (PS/kmq), areal coverage, kinematic coherence, mean visibility and velocity ± standard deviation for both ascending and descending datasets, plus the mean EWUD vector (using circular statistics for the angle). The selected VIS and EWUD layers do not need to be clipped to the study area. Exportable as PNG or CSV.

Version 3.2.6 adds acceleration detection to the InSAR Report module: for each dataset (ascending/descending), a piecewise linear regression with **exactly 2 fixed segments** (1 breakpoint, whose optimal position is still found automatically) is fitted to the mean coherent-PS time series, after removing the seasonal component (thermal/hydrological, typical of PSI data; period estimated from the actual acquisition cadence). The ratio between the two segments' velocities is reported (configurable threshold, default 1.5), along with the breakpoint date; a direction reversal between the two segments is flagged separately. The segment count is deliberately fixed at 2, not BIC-selected: a meaningful velocity ratio requires exactly two velocities to compare, and free-knot piecewise models tend to make BIC favor more segments than genuinely warranted (see the TS note below). Also adds the number of EWUD cells falling within the study area, shown next to the mean EWUD vector. Also fixes a bug (wrong pwlf attribute name, ".rss" instead of ".ssr") in the TS "Analisi non lineare piecewise" tool, which caused its BIC-based automatic segment count selection to silently fail (always falling back to the same default instead of genuinely testing segment counts via BIC); also fixes non-deterministic results from pwlf's optimizer by setting a fixed random seed, and removes the seasonal component before the fit for the same reason as above. The default for "Numero massimo di segmenti" is now 2 (was 5), still adjustable by the user; note that, unlike the Report module, this tool still uses BIC to pick among 2-5 segments and can occasionally favor more segments than a geologist would expect, due to the free-knot BIC effect described above — a known limitation of the underlying method, not a bug, left to the user's judgement for now.

Version 3.3.0 introduces compatibility with **QGIS 4 / Qt6**, distributed as a separate branch (see Installation section). The porting required fixing numerous Qt and QGIS enum references no longer valid under Qt6 (text alignment, dialogs, messages, field types), adapting the loading mechanism for the TS module's standalone scripts, and fixing a GDAL fid conflict on GeoPackage output and a coherent-PS matching bug (both unrelated to QGIS 4, but surfaced during testing). It also adds permanent GeoPackage saving to the **InSAR Polygons** module (already available in VIS and EWUD). The 3.2.x line for QGIS 3 continues to be maintained in parallel.

Version 3.3.1 fixes the same EWUD grid saving bug fixed in 3.2.3 for QGIS 3 (see above), unrelated to QGIS 4 but surfaced during testing on this branch.

Version 3.3.3 brings the same **InSAR Report** module introduced in 3.2.6 for QGIS 3 (see above) to this branch, including acceleration detection, with identical functionality.

### Modules

| Module | Description |
|--------|-------------|
| **InSAR Load** | Loads PSI point layers from GeoPackage, Shapefile or GDB using a polygon index layer, with automatic loading on map selection. Also supports reactivation of an index already loaded in the project. |
| **InSAR EWUD** | Reconstructs the velocity vector in the East-West / Up-Down plane from ascending/descending LOS velocities. Resampling grid with square or hexagonal cells. Includes satellite presets (Sentinel-1 EGMS - central-northern Italy, Sentinel-1 generic, ERS/Envisat, ALOS/ALOS-2, RADARSAT-2, COSMO-SkyMed, TerraSAR-X/TanDEM-X). Output includes Na and Nd fields (PS count per cell). |
| **InSAR VIS** | Calculates detectable movement percentage (pc_mov) based on SAR acquisition geometry and terrain morphology (Aspect/Slope from DEM). The DEM is clipped at its original resolution with snap to grid (targetAlignedPixels). Output can be saved as a permanent GeoPackage. Includes satellite presets (same as EWUD). Runs as a QgsTask (non-blocking GUI). |
| **InSAR TS** | Time series analysis: data quality check (with skewness and kurtosis), automatic mean series, STL seasonal decomposition, piecewise non-linear analysis (pwlf), temporal anomaly detection, multi-zone comparison. Supports DYYYYMMDD and YYYYMMDD date formats. "Load coherent PS to QGIS" button available in charts. |
| **InSAR Polygons** | Automatic delineation of deformation areas: PS classification by velocity threshold, buffer and geometric dissolve by velocity class, validation and morphological smoothing. Polygonal output with statistical attributes (mean velocity, PS count, area km²). Output can be saved as a permanent GeoPackage (from v3.3.0). |
| **InSAR Report** | Automatically generates a PSInSAR summary sheet for a study area (hand-drawn, loaded from a file, or picked from a project layer): PS count, density, areal coverage, kinematic coherence, visibility and velocity (with standard deviation) for both ascending and descending datasets, acceleration detection (configurable threshold), and the mean EWUD vector with the number of cells within the area. Exportable as PNG or CSV. |

### Satellite presets (VIS and EWUD modules)

| Satellite | Band | ASC az | ASC on | DESC az | DESC on |
|-----------|------|--------|--------|---------|---------|
| Sentinel-1 (EGMS - central-northern Italy) | C | 349° | 42° | 191° | 38° |
| Sentinel-1 (generic) | C | 348° | 33° | 192° | 33° |
| ERS / Envisat | C | 347° | 23° | 193° | 23° |
| ALOS / ALOS-2 | L | 350° | 34° | 190° | 34° |
| RADARSAT-2 | C | 350° | 35° | 190° | 35° |
| COSMO-SkyMed | X | 345° | 30° | 195° | 30° |
| TerraSAR-X / TanDEM-X | X | 350° | 35° | 190° | 35° |

> ASC azimuths are expressed in the [0°, 360°] convention (e.g. 349° = −11°). Formula results are identical — sin(349°) = sin(−11°).

### TS module tools

| Tool | Description |
|------|-------------|
| **Data quality** | Histogram + normal curve N(μ,σ), Q-Q plot, individual data boxplot, robust statistics (mean, std, median, IQR, MAD, skewness, kurtosis, robust z-score, Shapiro-Wilk). Real-time transformation selector. "Load coherent PS to QGIS" button. |
| **Automatic analysis** | Mean time series ±1σ, OLS trend with velocity and R², interactive tooltip, button to load the table into QGIS. "Load coherent PS to QGIS" button. |
| **STL decomposition** | Decomposition of the mean series into trend T(t), seasonality S(t) and residual R(t). "Load coherent PS to QGIS" button. |
| **Non-linear analysis** | Piecewise regression (pwlf), BIC optimisation, configurable maximum number of segments (2–5), summary table with period, velocity and R² per segment. "Load coherent PS to QGIS" button. |
| **Temporal anomalies** | Detection of anomalous acquisitions based on residual threshold (nσ) and consecutive variation threshold (Δmm). Interactive ⚠ ANOMALY tooltip. |
| **Zone comparison** | Comparison of mean time series between 2–3 zones with non-modal panel, ±1σ bands and OLS regression lines. |

### Requirements

- **QGIS 3.16 – 3.99** (plugin v3.2.x) or **QGIS 4.00+** (plugin v3.3.x, Qt6)
- Python 3 with libraries: `pandas`, `numpy`, `matplotlib`, `scipy`, `statsmodels`, `pyproj`, `mplcursors`, `pwlf`

> From v3.0 onwards, the `pykrige` library is no longer required by the main toolbar. Geostatistics is available as a standalone script in the `docs/` folder.

### Installation

**From QGIS Plugin Repository (recommended):**
1. In QGIS: *Plugins → Manage and Install Plugins → All*
2. Search for **InSAR Suite** and click *Install Plugin*

New versions are published to the official repository after review by a moderator (generally within one business day, excluding weekends; occasionally it may take a few days longer).

**From ZIP:**
1. Download the ZIP matching your QGIS version from the [Releases](../../releases) page: `InSAR_Suite_v3.2.6_QGIS3.zip` for QGIS 3, `InSAR_Suite_v3.3.3_QGIS4.zip` for QGIS 4
2. In QGIS: *Plugins → Manage and Install Plugins → Install from ZIP*
3. Enable the plugin from the installed list

**Manual installation:**

Copy the `InSAR_Suite/` folder to the QGIS plugins directory:
- Windows (QGIS 3): `C:\Users\<user>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Windows (QGIS 4): `C:\Users\<user>\AppData\Roaming\QGIS\QGIS4\profiles\default\python\plugins\`
- Linux / macOS (QGIS 3): `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
- Linux / macOS (QGIS 4): `~/.local/share/QGIS/QGIS4/profiles/default/python/plugins/`

### Quick start

1. **Load** — Load the PS point layer by selecting polygons from the index layer
2. **EWUD** — Create the resampling grid (square or hexagonal) and reconstruct the EW-UD velocity vector from ascending/descending pairs
3. **VIS** — Select the PS layer and DEM, define the processing extent and calculate pc_mov
4. **TS** — Set the PS layer as active, select points on the map, run the analyses in order: Data quality → Automatic analysis → STL decomposition → Non-linear → Anomalies → Zone comparison
5. **Polygons** — Select the PS layer, configure velocity threshold and buffer radius, run the automatic delineation of deformation areas

> TS modules require the PS vector layer to be active and points to be selected. If the active layer is a raster or no selection is present, the plugin shows a dedicated warning dialog with instructions.

### Expected data format for the TS module

PS layers must contain displacement fields in the format `DYYYYMMDD` (e.g. `D20170101`) or `YYYYMMDD` (e.g. `20170101`), one field per SAR acquisition date. Both formats are recognised automatically.

### Bug reports and contributions

Please open an [Issue](../../issues) on GitHub to report bugs or suggest improvements.

---

## Disclaimer

InSAR Suite is an independent open-source QGIS plugin for post-processing analysis of PSI (Persistent Scatterer Interferometry) displacement data, developed independently from other InSAR-related QGIS plugins and organisations. It is not affiliated with any organisation involved in the development or commercialisation of PSI processing algorithms. The results produced by this plugin are intended as a support tool for hazard and risk analysis (landslide, subsidence) and must always be evaluated in conjunction with other base data and verified in the field by a qualified professional.

---

## License

This plugin is released under the [GNU General Public License v2 or later](https://www.gnu.org/licenses/old-licenses/gpl-2.0.html), in compliance with QGIS licensing requirements.

## Author

Giovanni Montini — [g.montini@appenninosettentrionale.it](mailto:g.montini@appenninosettentrionale.it)
